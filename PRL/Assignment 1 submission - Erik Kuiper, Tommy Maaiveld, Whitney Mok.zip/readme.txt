The submission contains a PDF of the report, as well as:
main.py, the main script used to run all algorithms.
environment.py, which contains a class that defines the environment and its parameters.
Random_Policy.py, Value_Iteration.py, Howards_Policy_Iteration.py and Simple_Policy_Iteration.py, which define functions
to execute the corresponding methods.